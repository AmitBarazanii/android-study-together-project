package com.example.finalproject.Interfaces;

public interface ConnectionChangeCallback {
    public void connectionChange();
}
