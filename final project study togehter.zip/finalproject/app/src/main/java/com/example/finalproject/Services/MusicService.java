package com.example.finalproject.Services;

import static android.app.Service.START_STICKY;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.provider.Settings;

import androidx.annotation.Nullable;

import com.example.finalproject.R;

public class MusicService extends Service {
    private MediaPlayer player;
    boolean playing = false;

    @Override

    public int onStartCommand(Intent intent, int flags, int startId) {

        player = MediaPlayer.create( this, R.raw.music);
        player.setLooping( true );
        player.start();
        playing = true;

        return START_STICKY;
    }

    @Override

    public void onDestroy() {
        super.onDestroy();
        playing = false;
        player.stop();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public boolean isPlaying(){return playing;}
}
