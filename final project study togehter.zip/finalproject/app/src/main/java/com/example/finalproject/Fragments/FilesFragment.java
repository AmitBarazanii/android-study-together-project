package com.example.finalproject.Fragments;

import android.content.Intent;

import android.os.Bundle;
import androidx.fragment.app.Fragment;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.finalproject.R;
import com.example.finalproject.pdfActivity;

import java.util.ArrayList;
import java.util.List;

public class FilesFragment extends Fragment implements View.OnClickListener {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_files, container, false);

        Button button1 = view.findViewById(R.id.math58123);
        Button button2 = view.findViewById(R.id.math58223);
        Button button3 = view.findViewById(R.id.math582a23);
        Button button4 = view.findViewById(R.id.biology);
        Button button5 = view.findViewById(R.id.e24);
        Button button6 = view.findViewById(R.id.g24);
        Button button7 = view.findViewById(R.id.ph361);
        Button button8 = view.findViewById(R.id.ph371);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(getContext(), pdfActivity.class);

        switch (v.getId()){

            case R.id.math58123:
                intent.putExtra("pdfName", "581_23a");
                break;

            case R.id.math58223:
                intent.putExtra("pdfName", "582_23");
                break;

            case R.id.math582a23:
                intent.putExtra("pdfName", "582_23a");
                break;

            case R.id.e24:
                intent.putExtra("pdfName", "e_24");
                break;

            case R.id.g24:
                intent.putExtra("pdfName", "g_24");
                break;

            case R.id.biology:
                intent.putExtra("pdfName", "biology");
                break;

            case R.id.ph361:
                intent.putExtra("pdfName", "361_23");
                break;

            case R.id.ph371:
                intent.putExtra("pdfName", "371_23");
                break;

        }

        startActivity(intent);
    }
}