package com.example.finalproject.Receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.finalproject.Interfaces.ConnectionChangeCallback;

public class NetworkReceiver extends BroadcastReceiver  {
    private ConnectionChangeCallback listener;

    public NetworkReceiver(ConnectionChangeCallback listener){
        this.listener = listener;
    }
    public NetworkReceiver(){}
    @Override
    public void onReceive(Context context, Intent intent) {
        listener.connectionChange();
    }
}
