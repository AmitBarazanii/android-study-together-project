package com.example.finalproject.Fragments;

import static androidx.core.content.ContextCompat.registerReceiver;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.finalproject.Adapter.UserAdapter;
import com.example.finalproject.Interfaces.ConnectionChangeCallback;
import com.example.finalproject.Model.Chat;
import com.example.finalproject.Model.User;
import com.example.finalproject.R;
import com.example.finalproject.Receivers.NetworkReceiver;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class ChatsFragment extends Fragment implements ConnectionChangeCallback {
    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private List<User> mUser;
    FirebaseUser firebaseUser;
    DatabaseReference reference;
    private List<String> userlist;
    NetworkReceiver networkReceiver;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chats, container, false);

        recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        networkReceiver = new NetworkReceiver(this);
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(getContext(), networkReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        userlist = new ArrayList<>();
        findUsers();
        return view;
    }

    private void findUsers() {
        reference = FirebaseDatabase.getInstance("https://final-project-39557-default-rtdb.europe-west1.firebasedatabase.app/").getReference("Chats");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userlist.clear();
                for(DataSnapshot dataSnapshot: snapshot.getChildren()){
                    Chat chat = dataSnapshot.getValue(Chat.class);
                    if(chat.getSender().equals(firebaseUser.getUid()))
                        if(!userlist.contains(chat.getReceiver()))
                            userlist.add(chat.getReceiver());
                    if (chat.getReceiver().equals(firebaseUser.getUid()))
                        if(!userlist.contains(chat.getSender()))
                            userlist.add(chat.getSender());
                }
                readChats();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void readChats(){
        mUser = new ArrayList<>();
        reference = FirebaseDatabase.getInstance("https://final-project-39557-default-rtdb.europe-west1.firebasedatabase.app/").getReference("Users");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mUser.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    User user = dataSnapshot.getValue(User.class);
                    for (String id : userlist){
                        if(user.getId().equals(id)){
                            mUser.add(user);
                        }
                    }
                }

                firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                userAdapter = new UserAdapter(getContext(), mUser, true);
                if(firebaseUser != null)
                    recyclerView.setAdapter(userAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void connectionChange() {
        findUsers();
        Toast.makeText(getContext(), "אנא בדוק.י את החיבור לאינטרנט", Toast.LENGTH_SHORT).show();
    }
}