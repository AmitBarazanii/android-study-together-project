package com.example.finalproject;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class pdfActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf);

        Intent intent = getIntent();
        String str = intent.getStringExtra("pdfName");


        PDFView pdfView = findViewById(R.id.pdfView);

        pdfView.fromAsset(str).load();
    }
}